package ir.kasbyar.app

import android.app.*
import android.content.*
import android.media.MediaPlayer
import android.os.Bundle
import android.os.SystemClock
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import java.text.NumberFormat
import java.util.*
import kotlin.math.max
import kotlin.math.min

@Serializable
data class Product(
    var id: Long,
    var name: String,
    var cost: Long,
    var stock: Int,
    var maxPrice: Long = 0,
    var minStock: Int = 0,
    var bought: Int = 0,
    var sold: Int = 0,
    var purchaseTotal: Long = 0,
    var salesTotal: Long = 0,
    var active: Boolean = true
)

@Serializable
data class Event(
    var id: Long,
    var type: String,
    var productId: Long = 0,
    var productName: String = "",
    var qty: Int = 0,
    var amount: Long = 0,
    var cost: Long = 0,
    var payment: String = "",
    var note: String = "",
    var time: Long = System.currentTimeMillis(),
    var tipCash: Boolean = true,
    var dasht: Long = 0,
    var profit: Long = 0,
    var source: String = ""
)

@Serializable
data class Backup(
    val version: Int = 4,
    val products: List<Product>,
    val events: List<Event>,
    val nextId: Long = 1L,
    val soundMode: Int = 2,
    val currency: Int = 0,
    val minimumStock: Int = 0
)

enum class SoundMode { OFF, EFFECT, BOTH }

enum class Page { HOME, PURCHASE, SALE, TIP, EXPENSE, REPORTS, HISTORY, PRODUCTS, SETTINGS, BACKUP }

class MainActivity : AppCompatActivity() {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val prefs by lazy { getSharedPreferences("kasbyar", 0) }
    private var products = mutableListOf<Product>()
    private var events = mutableListOf<Event>()
    private var nextId = 1L
    private lateinit var root: LinearLayout
    private val nf = NumberFormat.getNumberInstance(Locale("fa", "IR"))
    private var page = Page.HOME
    private var lastBack = 0L

    // Currency is stored internally in toman. 0 = toman, 1 = rial.
    private val currency: Int get() = prefs.getInt("currency", 0)
    private fun unitName() = if (currency == 1) "ریال" else "تومان"
    private fun toBase(valueInSelectedUnit: Long): Long = if (currency == 1) valueInSelectedUnit / 10 else valueInSelectedUnit
    private fun fromBase(valueInToman: Long): Long = if (currency == 1) valueInToman * 10 else valueInToman

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        load()
        rebuild()
        home()
    }

    private fun load() {
        products = try { json.decodeFromString<List<Product>>(prefs.getString("products", "[]")!!).toMutableList() } catch (_: Exception) { mutableListOf() }
        events = try { json.decodeFromString<List<Event>>(prefs.getString("events", "[]")!!).toMutableList() } catch (_: Exception) { mutableListOf() }
        nextId = prefs.getLong("next", 1L)
    }

    private fun save() {
        prefs.edit()
            .putString("products", json.encodeToString(ListSerializer(Product.serializer()), products))
            .putString("events", json.encodeToString(ListSerializer(Event.serializer()), events))
            .putLong("next", nextId)
            .apply()
    }

    private fun txt(s: String, size: Float = 17f) = TextView(this).apply {
        text = s; textSize = size; setPadding(18, 18, 18, 18); contentDescription = s
    }

    private fun btn(s: String, action: () -> Unit) = Button(this).apply {
        text = s; textSize = 17f; isAllCaps = false; setOnClickListener { action() }
    }

    private fun base(title: String, target: Page) {
        page = target
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(16, 16, 16, 16)
        }
        root.addView(txt(title, 24f))
        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)
    }

    override fun onBackPressed() {
        if (page != Page.HOME) { home(); return }
        val now = SystemClock.elapsedRealtime()
        if (now - lastBack <= 2000) { finish(); return }
        lastBack = now
        toast("برای خروج دوباره دکمه بازگشت را بزنید.")
    }

    private fun home() {
        base("کاسبیار", Page.HOME)
        val today = events.filter { isToday(it.time) }
        val sales = today.filter { it.type == "sale" }
        val tips = today.filter { it.type == "tip" }
        val expenses = today.filter { it.type == "expense" }
        val salesProfit = sales.sumOf { it.profit }
        val tipProfit = tips.sumOf { it.amount }
        val finalProfit = salesProfit + tipProfit - expenses.sumOf { it.amount }
        val inventoryValue = products.filter { it.active }.sumOf { it.stock.toLong() * it.cost }
        val purchaseTotalToday = today.filter { it.type == "purchase" }.sumOf { it.amount }
        val salesCostToday = sales.sumOf { it.cost * it.qty }
        val capital = maxOf(0L, purchaseTotalToday - salesCostToday)

        root.addView(txt("فروش امروز: ${money(sales.sumOf { it.amount - it.dasht })} ${unitName()}"))
        root.addView(txt("دشت امروز: ${money(tipProfit)} ${unitName()}"))
        root.addView(txt("هزینه امروز: ${money(expenses.sumOf { it.amount })} ${unitName()}"))
        root.addView(txt("سود نهایی امروز: ${money(finalProfit)} ${unitName()}"))
        root.addView(txt("موجودی کالا: ${products.sumOf { it.stock }} عدد"))
        root.addView(txt("سرمایه درگیر در کالاها: ${money(inventoryValue)} ${unitName()}"))
        root.addView(txt("مانده سرمایه خرید: ${money(capital)} ${unitName()}"))

        root.addView(btn("ثبت خرید") { purchase() })
        root.addView(btn("ثبت فروش") { sale() })
        root.addView(btn("ثبت دشت") { tip() })
        root.addView(btn("ثبت خرجکرد") { expense() })
        root.addView(btn("گزارش‌ها") { reports() })
        root.addView(btn("سوابق تراکنش‌ها") { history() })
        root.addView(btn("کالاها و موجودی") { productsPage() })
        root.addView(btn("تنظیمات") { settings() })
        root.addView(btn("پشتیبان‌گیری / بازیابی") { backupPage() })
    }

    private fun field(h: String, value: String = "") = EditText(this).apply {
        hint = h; textSize = 17f; setText(value); inputType = 2
    }

    private fun nameField(h: String, value: String = "") = EditText(this).apply {
        hint = h; textSize = 17f; setText(value)
    }

    private fun chooseProduct(prompt: String, onPick: (Product) -> Unit) {
        val activeProducts = products.filter { it.active }
        if (activeProducts.isEmpty()) { toast("هنوز کالایی ثبت نشده است"); return }
        val names = activeProducts.map { it.name }.toTypedArray()
        AlertDialog.Builder(this).setTitle(prompt).setItems(names) { _, i -> onPick(activeProducts[i]) }
            .setNegativeButton("انصراف", null).show()
    }

    private fun purchase() {
        val d = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 10, 20, 10) }
        val n = nameField("نام کالای جدید یا انتخاب کالای موجود")
        val c = field("قیمت خرید هر واحد به ${unitName()}")
        val q = field("تعداد")
        d.addView(n); d.addView(c); d.addView(q)
        d.addView(btn("انتخاب کالای موجود") { chooseProduct("انتخاب کالا") { n.setText(it.name); n.tag = it.id } })
        AlertDialog.Builder(this).setTitle("ثبت خرید").setView(d).setPositiveButton("ثبت") { _, _ ->
            val name = n.text.toString().trim()
            val costSelected = c.text.toString().filter { it.isDigit() }.toLongOrNull() ?: 0
            val qty = q.text.toString().filter { it.isDigit() }.toIntOrNull() ?: 0
            val cost = toBase(costSelected)
            if (name.isBlank() || cost <= 0 || qty <= 0) { toast("اطلاعات خرید کامل نیست"); return@setPositiveButton }
            val p = products.find { it.id == (n.tag as? Long) } ?: products.find { it.name == name }
            val x = p ?: Product(nextId++, name, cost, 0, minStock = prefs.getInt("minimum_stock", 0), active = true)
            if (p == null) products.add(x)
            x.stock += qty; x.bought += qty; x.purchaseTotal += cost * qty
            events.add(Event(nextId++, "purchase", x.id, x.name, qty, cost * qty, cost, note = "خرید"))
            rebuild(); save(); sound("buy"); home()
        }.setNegativeButton("انصراف", null).show()
    }

    private fun sale() {
        if (products.isEmpty()) { toast("ابتدا کالا ثبت کنید"); return }
        chooseProduct("انتخاب کالا برای فروش") { p ->
            val d = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 10, 20, 10) }
            val q = field("تعداد فروش")
            val price = field("قیمت کل این تعداد به ${unitName()}")
            val pay = Spinner(this).apply {
                adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("نقدی", "کارتخوان", "کارت‌به‌کارت"))
            }
            d.addView(q); d.addView(price); d.addView(pay)
            AlertDialog.Builder(this).setTitle("فروش ${p.name}").setView(d).setPositiveButton("ثبت") { _, _ ->
                val qty = q.text.toString().filter { it.isDigit() }.toIntOrNull() ?: 0
                val total = toBase(price.text.toString().filter { it.isDigit() }.toLongOrNull() ?: 0)
                if (qty <= 0 || total <= 0 || qty > p.stock) { toast("تعداد یا قیمت نامعتبر است"); return@setPositiveButton }
                val oldStock = p.stock
                val maxUnit = p.maxPrice
                val allowed = if (maxUnit > 0) min(total, maxUnit * qty.toLong()) else total
                val dasht = maxOf(0L, total - allowed)
                val profit = allowed - p.cost * qty
                p.stock -= qty; p.sold += qty; p.salesTotal += allowed
                events.add(Event(nextId++, "sale", p.id, p.name, qty, total, p.cost, pay.selectedItem.toString(), dasht = dasht, profit = profit))
                if (dasht > 0) events.add(Event(nextId++, "tip", p.id, p.name, 0, dasht, payment = pay.selectedItem.toString(), note = "دشت خودکار از فروش"))
                save(); sound("sale") { checkStockAlert(p, oldStock); home() }
            }.setNegativeButton("انصراف", null).show()
        }
    }

    private fun tip() {
        val d = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val a = field("مبلغ دشت به ${unitName()}")
        val pay = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("نقدی", "کارتخوان", "کارت‌به‌کارت")) }
        d.addView(a); d.addView(pay)
        AlertDialog.Builder(this).setTitle("ثبت دشت").setView(d).setPositiveButton("ثبت") { _, _ ->
            val x = toBase(a.text.toString().filter { it.isDigit() }.toLongOrNull() ?: 0)
            if (x > 0) { events.add(Event(nextId++, "tip", amount = x, payment = pay.selectedItem.toString(), note = "دشت")); save(); sound("tip"); home() }
        }.setNegativeButton("انصراف", null).show()
    }

    private fun availableTip(payment: String, until: Long = Long.MAX_VALUE): Long {
        val tips = events.filter { it.type == "tip" && it.payment == payment && it.time <= until }.sumOf { it.amount }
        val expenses = events.filter { it.type == "expense" && it.source == payment && it.time <= until }.sumOf { it.amount }
        return tips - expenses
    }

    private fun expense() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val a = field("مبلغ خرجکرد به ${unitName()}")
        val n = nameField("شرح خرجکرد")
        val source = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("دشت نقدی", "دشت کارتخوان", "دشت کارت‌به‌کارت")) }
        box.addView(a); box.addView(n); box.addView(source)
        AlertDialog.Builder(this).setTitle("ثبت خرجکرد").setView(box).setPositiveButton("ثبت") { _, _ ->
            val x = toBase(a.text.toString().filter { it.isDigit() }.toLongOrNull() ?: 0)
            if (x <= 0) return@setPositiveButton
            val src = source.selectedItem.toString().removePrefix("دشت ")
            val available = availableTip(src)
            if (x > available) {
                val shortfall = x - maxOf(0L, available)
                AlertDialog.Builder(this).setTitle("موجودی منبع کافی نیست")
                    .setMessage("از $src فقط ${money(maxOf(0L, available))} ${unitName()} موجود است. کسری ${money(shortfall)} ${unitName()} از سود فروش نقدی تأمین می‌شود. ادامه می‌دهید؟")
                    .setPositiveButton("ثبت خرجکرد") { _, _ -> addExpense(x, n.text.toString(), src) }
                    .setNegativeButton("انصراف", null).show()
            } else addExpense(x, n.text.toString(), src)
        }.setNegativeButton("انصراف", null).show()
    }

    private fun addExpense(amount: Long, note: String, source: String) {
        val available = availableTip(source)
        val finalSource = if (amount > maxOf(0L, available)) "$source + سود فروش نقدی" else source
        events.add(Event(nextId++, "expense", amount = amount, note = note, source = finalSource)); save(); sound("expense"); home()
    }

    private fun productsPage() {
        base("کالاها و موجودی", Page.PRODUCTS)
        if (products.isEmpty()) root.addView(txt("هنوز کالایی ثبت نشده است."))
        products.filter { it.active }.forEach { p ->
            val lastPurchase = events.filter { it.type == "purchase" && it.productId == p.id }.maxByOrNull { it.time }
            val soldSince = if (lastPurchase == null) 0 else events.filter { it.type == "sale" && it.productId == p.id && it.time >= lastPurchase.time }.sumOf { it.qty }
            val remainingSince = if (lastPurchase == null) p.stock else maxOf(0, lastPurchase.qty - soldSince)
            root.addView(txt("${p.name} — موجودی ${p.stock} — خرید ${money(p.cost)} ${unitName()} — حداکثر فروش ${if (p.maxPrice > 0) money(p.maxPrice) else "تعیین نشده"} — حداقل ${p.minStock}"))
            if (lastPurchase != null) root.addView(txt("از آخرین خرید: خرید ${lastPurchase.qty}، فروش ${soldSince}، باقی‌مانده ${remainingSince}"))
            events.filter { it.productId == p.id && it.type in setOf("purchase", "sale", "tip") }.sortedByDescending { it.time }.take(20).forEach { e ->
                val detail = when (e.type) {
                    "purchase" -> "خرید ${e.qty} عدد، مبلغ ${money(e.amount)} ${unitName()}"
                    "sale" -> "فروش ${e.qty} عدد، مبلغ ${money(e.amount)} ${unitName()}، دشت ${money(e.dasht)} ${unitName()}"
                    else -> "دشت ${money(e.amount)} ${unitName()}"
                }
                root.addView(txt("${jalali(e.time)} — $detail"))
            }
            root.addView(btn("ویرایش ${p.name}") { editProduct(p) })
            root.addView(btn("حذف ${p.name}") { deleteProduct(p) })
        }
        root.addView(btn("بازگشت") { home() })
    }

    private fun editProduct(p: Product) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val cost = field("قیمت خرید فعلی", fromBase(p.cost).toString())
        val maxP = field("حداکثر قیمت فروش", if (p.maxPrice > 0) fromBase(p.maxPrice).toString() else "")
        val minS = field("حداقل موجودی", p.minStock.toString())
        box.addView(cost); box.addView(maxP); box.addView(minS)
        AlertDialog.Builder(this).setTitle(p.name).setView(box).setPositiveButton("ذخیره") { _, _ ->
            p.cost = toBase(cost.text.toString().filter { it.isDigit() }.toLongOrNull() ?: fromBase(p.cost))
            p.maxPrice = toBase(maxP.text.toString().filter { it.isDigit() }.toLongOrNull() ?: 0)
            p.minStock = minS.text.toString().filter { it.isDigit() }.toIntOrNull() ?: 0
            save(); sound("edit"); productsPage()
        }.setNegativeButton("انصراف", null).show()
    }

    private fun deleteProduct(p: Product) {
        AlertDialog.Builder(this).setTitle("حذف کالا")
            .setMessage("کالای «${p.name}» از فروش، خرید و موجودی فعلی حذف می‌شود؛ سوابق قبلی آن باقی می‌ماند. ادامه می‌دهید؟")
            .setPositiveButton("حذف کالا") { _, _ -> p.active = false; save(); sound("delete"); productsPage() }
            .setNeutralButton("حذف کامل کالا و سوابق مرتبط") { _, _ ->
                AlertDialog.Builder(this).setTitle("تأیید حذف کامل")
                    .setMessage("تمام خریدها، فروش‌ها، دشت‌های مرتبط و سوابق کالای «${p.name}» برای همیشه حذف می‌شوند. این کار قابل بازگشت نیست.")
                    .setPositiveButton("بله، حذف کامل") { _, _ -> events.removeIf { it.productId == p.id }; products.removeIf { it.id == p.id }; rebuild(); save(); sound("delete"); productsPage() }
                    .setNegativeButton("انصراف", null).show()
            }
            .setNegativeButton("انصراف", null).show()
    }

    private fun reports() {
        base("گزارش‌ها", Page.REPORTS)
        root.addView(btn("امروز") { sound("report"); reportRange(0) })
        root.addView(btn("این ۷ روز") { sound("report"); reportRange(7) })
        root.addView(btn("این ۳۰ روز") { sound("report"); reportRange(30) })
        root.addView(btn("امسال") { sound("report"); reportRange(365) })
        root.addView(btn("تاریخ شمسی مشخص") { persianDateReport(false) })
        root.addView(btn("بازه تاریخ شمسی") { persianDateReport(true) })
        root.addView(btn("گزارش موجودی و سرمایه") { inventoryReport() })
        root.addView(btn("بازگشت") { home() })
    }

    private fun reportRange(days: Int) {
        val now = System.currentTimeMillis()
        val from = if (days == 0) startDay(now) else startDay(now) - (days - 1) * 86400000L
        showReport(events.filter { it.time >= from })
    }

    private fun persianDateReport(range: Boolean) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val a = nameField("از تاریخ شمسی: 1405/01/01"); box.addView(a)
        val b = if (range) nameField("تا تاریخ شمسی: 1405/01/01").also { box.addView(it) } else null
        AlertDialog.Builder(this).setTitle("گزارش بر اساس تاریخ شمسی").setView(box).setPositiveButton("نمایش") { _, _ ->
            val x = parseJalali(a.text.toString()); val y = if (range) parseJalali(b!!.text.toString()) else x
            if (x == null || y == null) { toast("تاریخ شمسی نامعتبر است"); return@setPositiveButton }
            sound("report")
            showReport(events.filter { it.time >= x && it.time < y + 86400000L })
        }.setNegativeButton("انصراف", null).show()
    }

    private fun showReport(es: List<Event>) {
        base("نتیجه گزارش", Page.REPORTS)
        val sales = es.filter { it.type == "sale" }
        val purchases = es.filter { it.type == "purchase" }
        val tips = es.filter { it.type == "tip" }
        val expenses = es.filter { it.type == "expense" }
        val saleRevenue = sales.sumOf { it.amount - it.dasht }
        val saleProfit = sales.sumOf { it.profit }
        val tipTotal = tips.sumOf { it.amount }
        val expenseTotal = expenses.sumOf { it.amount }
        val finalProfit = saleProfit + tipTotal - expenseTotal
        val purchaseTotal = purchases.sumOf { it.amount }
        val workingDays = sales.map { startDay(it.time) }.distinct().sorted()

        root.addView(txt("فروش: ${money(saleRevenue)} ${unitName()}"))
        root.addView(txt("سود حاصل از فروش: ${money(saleProfit)} ${unitName()}"))
        root.addView(txt("سود حاصل از دشت: ${money(tipTotal)} ${unitName()}"))
        root.addView(txt("هزینه: ${money(expenseTotal)} ${unitName()}"))
        root.addView(txt("سود نهایی: ${money(finalProfit)} ${unitName()}"))
        root.addView(txt("درصد سود فروش: ${if (saleRevenue > 0) String.format(Locale.US, "%.1f", saleProfit * 100.0 / saleRevenue) else "0"}%"))
        root.addView(txt("کل خرید: ${money(purchaseTotal)} ${unitName()}"))
        val purchaseGap = maxOf(0L, purchaseTotal - sales.sumOf { it.cost * it.qty })
        root.addView(txt("مانده سرمایه خرید: ${money(purchaseGap)} ${unitName()}"))
        val inventoryCapital = products.filter { it.active }.sumOf { it.stock.toLong() * it.cost }
        val breakEven = maxOf(0L, inventoryCapital - saleProfit)
        root.addView(txt("میزان فروش برای رسیدن به نقطه سر به سر: ${money(breakEven)} ${unitName()}"))
        root.addView(txt("تعداد روزهای کارکرد: ${workingDays.size}"))
        if (workingDays.isNotEmpty()) root.addView(txt(workingDays.joinToString("\n") { weekdayJalali(it) }))
        root.addView(txt("میانگین سود نهایی هر روز کارکرد: ${money(if (workingDays.isEmpty()) 0 else finalProfit / workingDays.size)} ${unitName()}"))

        root.addView(txt("فروش نقدی: ${money(sales.filter { it.payment == "نقدی" }.sumOf { it.amount - it.dasht })} ${unitName()}"))
        root.addView(txt("فروش کارتخوان: ${money(sales.filter { it.payment == "کارتخوان" }.sumOf { it.amount - it.dasht })} ${unitName()}"))
        root.addView(txt("فروش کارت‌به‌کارت: ${money(sales.filter { it.payment == "کارت‌به‌کارت" }.sumOf { it.amount - it.dasht })} ${unitName()}"))
        root.addView(txt("دشت نقدی: ${money(tips.filter { it.payment == "نقدی" }.sumOf { it.amount })} ${unitName()}"))
        root.addView(txt("دشت کارتخوان: ${money(tips.filter { it.payment == "کارتخوان" }.sumOf { it.amount })} ${unitName()}"))
        root.addView(txt("دشت کارت‌به‌کارت: ${money(tips.filter { it.payment == "کارت‌به‌کارت" }.sumOf { it.amount })} ${unitName()}"))

        products.filter { it.active }.distinctBy { it.id }.forEach { p ->
            val ps = sales.filter { it.productId == p.id }
            if (ps.isNotEmpty()) {
                val groups = ps.groupBy { it.qty }.toSortedMap()
                val text = groups.entries.joinToString("، ") { "${it.value.size} فروش ${it.key}تایی" }
                val productProfit = ps.sumOf { it.profit }
                val productRevenue = ps.sumOf { it.amount - it.dasht }
                root.addView(txt("${p.name}: $text — فروش ${money(productRevenue)} ${unitName()} — سود ${money(productProfit)} ${unitName()}"))
            }
        }
        root.addView(btn("بازگشت") { reports() })
    }

    private fun inventoryReport() {
        base("موجودی و سرمایه درگیر", Page.REPORTS)
        val inventory = products.filter { it.active }.sumOf { it.stock.toLong() }
        val capital = products.filter { it.active }.sumOf { it.stock.toLong() * it.cost }
        root.addView(txt("تعداد کل موجودی: $inventory عدد"))
        root.addView(txt("سرمایه درگیر در موجودی: ${money(capital)} ${unitName()}"))
        products.filter { it.active }.forEach { root.addView(txt("${it.name}: ${it.stock} عدد × ${money(it.cost)} ${unitName()} = ${money(it.stock * it.cost)} ${unitName()}")) }
        root.addView(btn("بازگشت") { reports() })
    }

    private fun history() {
        base("سوابق تراکنش‌ها", Page.HISTORY)
        val search = nameField("جستجو در سوابق")
        root.addView(search)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        fun render(q: String) {
            list.removeAllViews()
            events.sortedByDescending { it.time }.filter {
                q.isBlank() || (it.productName + " " + it.note + " " + it.type + " " + it.payment + " " + it.source).contains(q, true)
            }.forEach { e ->
                val desc = when (e.type) {
                    "sale" -> "فروش ${e.productName}، تعداد ${e.qty}، مبلغ ${money(e.amount)}، دشت ${money(e.dasht)}، ${e.payment}"
                    "purchase" -> "خرید ${e.productName}، تعداد ${e.qty}، مبلغ ${money(e.amount)}"
                    "tip" -> "دشت: ${money(e.amount)} — ${e.payment}"
                    "expense" -> "خرجکرد: ${money(e.amount)} — منبع ${e.source} — ${e.note}"
                    else -> e.type
                }
                list.addView(txt("${jalali(e.time)} — $desc"))
                list.addView(btn("ویرایش / حذف") { editEvent(e) })
            }
        }
        search.addTextChangedListener(SimpleTextWatcher { render(it) })
        render("")
        root.addView(btn("بازگشت") { home() })
    }

    private fun editEvent(e: Event) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val amount = field("مبلغ به ${unitName()}", fromBase(e.amount).toString())
        val qty = if (e.type == "sale" || e.type == "purchase") field("تعداد", e.qty.toString()) else null
        val cost = if (e.type == "purchase") field("قیمت خرید هر واحد", fromBase(e.cost).toString()) else null
        val note = nameField("شرح", e.note)
        if (qty != null) box.addView(qty)
        if (cost != null) box.addView(cost)
        box.addView(amount); box.addView(note)
        val payment = if (e.type == "sale" || e.type == "tip") Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("نقدی", "کارتخوان", "کارت‌به‌کارت"))
            setSelection(listOf("نقدی","کارتخوان","کارت‌به‌کارت").indexOf(e.payment).coerceAtLeast(0))
        } else null
        if (payment != null) box.addView(payment)
        AlertDialog.Builder(this).setTitle("ویرایش عملیات").setView(box)
            .setPositiveButton("ذخیره") { _, _ ->
                if (qty != null) e.qty = qty.text.toString().filter { it.isDigit() }.toIntOrNull() ?: e.qty
                if (cost != null) e.cost = toBase(cost.text.toString().filter { it.isDigit() }.toLongOrNull() ?: fromBase(e.cost))
                e.amount = toBase(amount.text.toString().filter { it.isDigit() }.toLongOrNull() ?: fromBase(e.amount))
                e.note = note.text.toString()
                if (payment != null) e.payment = payment.selectedItem.toString()
                if (e.type == "purchase" && qty != null && cost != null) e.amount = e.qty * e.cost
                recalcEvent(e); rebuild(); save(); sound("edit"); history()
            }
            .setNeutralButton("حذف") { _, _ ->
                events.removeIf { it.id == e.id }; rebuild(); save(); sound("delete"); history()
            }
            .setNegativeButton("انصراف", null).show()
    }

    private fun recalcEvent(e: Event) {
        if (e.type == "sale") {
            val p = products.find { it.id == e.productId }
            if (p != null) {
                val allowed = if (p.maxPrice > 0) min(e.amount, p.maxPrice * e.qty.toLong()) else e.amount
                e.dasht = maxOf(0L, e.amount - allowed)
                e.profit = allowed - e.cost * e.qty
            }
        }
    }

    private fun settings() {
        base("تنظیمات", Page.SETTINGS)
        val mode = SoundMode.values()[prefs.getInt("sound", 2).coerceIn(0, 2)]
        root.addView(txt("حالت فعلی صدا: ${modeLabel(mode)}"))
        root.addView(btn("خاموش") { prefs.edit().putInt("sound", 0).apply(); settings() })
        root.addView(btn("فقط افکت") { prefs.edit().putInt("sound", 1).apply(); settings() })
        root.addView(btn("افکت + اعلان صوتی") { prefs.edit().putInt("sound", 2).apply(); settings() })
        root.addView(txt("واحد پول فعلی: ${unitName()}"))
        root.addView(btn("تومان") { prefs.edit().putInt("currency", 0).apply(); settings() })
        root.addView(btn("ریال") { prefs.edit().putInt("currency", 1).apply(); settings() })
        root.addView(txt("حداقل موجودی کالا: ${prefs.getInt("minimum_stock", 0)}"))
        root.addView(btn("تعیین حداقل موجودی کالا") { setMinimumStock() })
        root.addView(btn("پاک کردن تمام اطلاعات") { clearAllData() })
        root.addView(btn("بازگشت") { home() })
    }

    private fun setMinimumStock() {
        val a = field("حداقل موجودی کالا", prefs.getInt("minimum_stock", 0).toString())
        AlertDialog.Builder(this).setTitle("حداقل موجودی").setView(a).setPositiveButton("ذخیره") { _, _ ->
            prefs.edit().putInt("minimum_stock", a.text.toString().filter { it.isDigit() }.toIntOrNull() ?: 0).apply(); settings()
        }.setNegativeButton("انصراف", null).show()
    }

    private fun clearAllData() {
        AlertDialog.Builder(this).setTitle("هشدار جدی")
            .setMessage("همه کالاها، خریدها، فروش‌ها، دشت‌ها، خرجکردها و سوابق حذف می‌شوند. نسخه‌های پشتیبان محلی حذف نمی‌شوند. این کار قابل بازگشت نیست.")
            .setPositiveButton("ادامه") { _, _ ->
                AlertDialog.Builder(this).setTitle("تأیید نهایی")
                    .setMessage("مطمئن هستید که تمام اطلاعات فعلی کاسبیار پاک شود؟")
                    .setPositiveButton("بله، پاک شود") { _, _ ->
                        products.clear(); events.clear(); nextId = 1L; save(); home(); toast("تمام اطلاعات پاک شد")
                    }.setNegativeButton("انصراف", null).show()
            }.setNegativeButton("انصراف", null).show()
    }

    private fun backupPage() {
        base("پشتیبان‌گیری و بازیابی", Page.BACKUP)
        root.addView(txt("نسخه پشتیبان شامل کالاها، خریدها، فروش‌ها، دشت‌ها، خرجکردها و تنظیمات برنامه است."))
        root.addView(btn("تهیه نسخه پشتیبان") {
            val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                type = "application/json"; addCategory(Intent.CATEGORY_OPENABLE); putExtra(Intent.EXTRA_TITLE, "kasbyar_backup.json")
            }
            startActivityForResult(i, 10)
        })
        root.addView(btn("بازیابی نسخه پشتیبان") {
            AlertDialog.Builder(this).setTitle("بازیابی اطلاعات")
                .setMessage("با بازیابی، اطلاعات فعلی کاسبیار با اطلاعات فایل پشتیبان جایگزین می‌شود. ادامه می‌دهید؟")
                .setPositiveButton("بله، بازیابی شود") { _, _ ->
                    val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "application/json"; addCategory(Intent.CATEGORY_OPENABLE) }
                    startActivityForResult(i, 11)
                }.setNegativeButton("انصراف", null).show()
        })
        root.addView(btn("بازگشت") { home() })
    }

    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        super.onActivityResult(r, c, d)
        if (c != RESULT_OK || d?.data == null) return
        try {
            if (r == 10) {
                val backup = Backup(2, products.toList(), events.toList(), nextId, prefs.getInt("sound", 2), currency, prefs.getInt("minimum_stock", 0))
                contentResolver.openOutputStream(d.data!!)?.use { it.write(json.encodeToString(Backup.serializer(), backup).toByteArray(Charsets.UTF_8)) }
                    ?: throw Exception("output")
                toast("نسخه پشتیبان با موفقیت ساخته شد")
            } else if (r == 11) {
                val s = contentResolver.openInputStream(d.data!!)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: throw Exception("input")
                val b = json.decodeFromString<Backup>(s)
                if (b.version < 1) throw Exception("version")
                products = b.products.toMutableList(); events = b.events.toMutableList()
                nextId = maxOf(b.nextId, (products.map { it.id } + events.map { it.id }).maxOrNull()?.plus(1) ?: 1L)
                prefs.edit().putInt("sound", b.soundMode.coerceIn(0, 2)).putInt("currency", b.currency.coerceIn(0, 1)).putInt("minimum_stock", b.minimumStock.coerceAtLeast(0)).apply()
                rebuild(); save(); home(); toast("بازیابی با موفقیت انجام شد")
            }
        } catch (_: Exception) { toast("بازیابی انجام نشد؛ فایل پشتیبان معتبر نیست") }
    }

    private fun sound(op: String, after: (() -> Unit)? = null) {
        val m = SoundMode.values()[prefs.getInt("sound", 2).coerceIn(0, 2)]
        if (m == SoundMode.OFF) { after?.invoke(); return }
        val effect = resources.getIdentifier("${op}_effect", "raw", packageName)
        val voiceName = if (op == "low_stock" || op == "out_of_stock") "${op}_alert" else "${op}_success"
        val voice = resources.getIdentifier(voiceName, "raw", packageName)
        if (effect <= 0) { after?.invoke(); return }
        MediaPlayer.create(this, effect)?.apply {
            setOnCompletionListener {
                release()
                if (m == SoundMode.BOTH && voice > 0) {
                    MediaPlayer.create(this@MainActivity, voice)?.apply {
                        setOnCompletionListener { release(); after?.invoke() }
                        start()
                    } ?: after?.invoke()
                } else after?.invoke()
            }
            start()
        } ?: after?.invoke()
    }

    private fun checkStockAlert(p: Product, previousStock: Int) {
        // The setting in Settings is the global default/minimum-stock threshold.
        // Older products may still have minStock=0, so use the global setting for them too.
        val threshold = if (p.minStock > 0) p.minStock else prefs.getInt("minimum_stock", 0).coerceAtLeast(0)
        val outReached = previousStock > 0 && p.stock <= 0
        val lowReached = threshold > 0 && previousStock > threshold && p.stock in 1..threshold

        when {
            outReached -> {
                events.add(Event(nextId++, "stock_alert", p.id, p.name, note = "out"))
                save()
                sound("out_of_stock")
            }
            lowReached -> {
                events.add(Event(nextId++, "stock_alert", p.id, p.name, note = "low"))
                save()
                sound("low_stock")
            }
        }
    }

    private fun rebuild() {
        products.forEach { it.stock = 0; it.bought = 0; it.sold = 0; it.purchaseTotal = 0; it.salesTotal = 0; it.cost = 0 }
        events.filter { it.type == "purchase" }.sortedBy { it.time }.forEach { e ->
            products.find { it.id == e.productId }?.apply {
                stock += e.qty; bought += e.qty; purchaseTotal += e.amount
                cost = if (bought > 0) purchaseTotal / bought else e.cost
            }
        }
        events.filter { it.type == "sale" }.sortedBy { it.time }.forEach { e ->
            products.find { it.id == e.productId }?.apply {
                stock -= e.qty; sold += e.qty; salesTotal += (e.amount - e.dasht)
            }
        }
        products.forEach { if (it.stock < 0) it.stock = 0 }
    }

    private fun money(x: Long) = nf.format(fromBase(x))
    private fun isToday(t: Long) = startDay(t) == startDay(System.currentTimeMillis())
    private fun startDay(t: Long): Long = Calendar.getInstance().apply { timeInMillis = t; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis

    private fun weekdayJalali(ms: Long): String {
        val c = Calendar.getInstance().apply { timeInMillis = ms }
        val names = arrayOf("یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه")
        return "${names[c.get(Calendar.DAY_OF_WEEK) - 1]}، ${jalali(ms).substringBefore(' ')}"
    }

    private fun jalali(ms: Long): String {
        val c = Calendar.getInstance().apply { timeInMillis = ms }
        val (jy, jm, jd) = gregorianToJalali(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
        return "$jy/${jm.toString().padStart(2, '0')}/${jd.toString().padStart(2, '0')} ${String.format(Locale.US, "%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))}"
    }

    private fun parseJalali(s: String): Long? {
        return try {
            val a = s.trim().split('/')
            if (a.size != 3) return null
            val g = jalaliToGregorian(a[0].toInt(), a[1].toInt(), a[2].toInt())
            Calendar.getInstance().apply {
                set(g[0], g[1] - 1, g[2], 0, 0, 0)
                set(Calendar.MILLISECOND, 0)
            }.timeInMillis
        } catch (_: Exception) {
            null
        }
    }

    private fun gregorianToJalali(gy0: Int, gm0: Int, gd: Int): Triple<Int, Int, Int> {
        var gy = gy0 - 1600; val gm = gm0 - 1; val gd2 = gd - 1
        val gdm = intArrayOf(31,28,31,30,31,30,31,31,30,31,30,31)
        var days = 365 * gy + (gy + 3) / 4 - (gy + 99) / 100 + (gy + 399) / 400
        for (i in 0 until gm) days += gdm[i]
        if (gm > 1 && ((gy0 % 4 == 0 && gy0 % 100 != 0) || gy0 % 400 == 0)) days++
        days += gd2
        var j = days - 79; val jy = 979 + 33 * (j / 12053); j %= 12053
        var jy2 = jy + 4 * (j / 1461); j %= 1461
        if (j >= 366) { jy2 += (j - 1) / 365; j = (j - 1) % 365 }
        val jm = if (j < 186) 1 + j / 31 else 7 + (j - 186) / 30
        val jd = 1 + if (j < 186) j % 31 else (j - 186) % 30
        return Triple(jy2, jm, jd)
    }

    private fun jalaliToGregorian(jy0: Int, jm: Int, jd: Int): IntArray {
        var jy = jy0 - 979; var jday = 365 * jy + (jy / 33) * 8 + ((jy % 33 + 3) / 4)
        for (i in 1 until jm) jday += if (i <= 6) 31 else 30
        jday += jd - 1
        var gy = 1600 + 400 * (jday / 146097); jday %= 146097; var leap = true
        if (jday >= 36525) { jday--; gy += 100 * (jday / 36524); jday %= 36524; if (jday >= 365) jday++ else leap = false }
        gy += 4 * (jday / 1461); jday %= 1461
        if (jday >= 366) { leap = false; jday--; gy += jday / 365; jday %= 365 }
        val gd = intArrayOf(31, if (leap) 29 else 28, 31,30,31,30,31,31,30,31,30,31); var gm = 0
        while (gm < 12 && jday >= gd[gm]) { jday -= gd[gm]; gm++ }
        return intArrayOf(gy, gm + 1, jday + 1)
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun modeLabel(m: SoundMode) = when (m) { SoundMode.OFF -> "خاموش"; SoundMode.EFFECT -> "فقط افکت"; SoundMode.BOTH -> "افکت + اعلان صوتی" }

    private class SimpleTextWatcher(val onChange: (String) -> Unit) : android.text.TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) = Unit
        override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) { onChange(s?.toString() ?: "") }
        override fun afterTextChanged(s: android.text.Editable?) = Unit
    }
}
