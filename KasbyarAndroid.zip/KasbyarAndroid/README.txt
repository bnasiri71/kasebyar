کاسبیار - Android WebView project

این پروژه فایل HTML کاسبیار را به صورت یک اپ اندرویدی بسته‌بندی می‌کند.

ساخت APK:
1) پروژه را در Android Studio باز کنید.
2) صبر کنید Gradle و Android SDK لازم دانلود/Sync شوند.
3) از منوی Build > Build APK(s) خروجی بگیرید.

Application ID: ir.kasbyar.app
Version: 1.0 (code 1)
Minimum Android: 6.0 (API 23)

نکته: داده‌های برنامه در localStorage خود WebView ذخیره می‌شوند.
